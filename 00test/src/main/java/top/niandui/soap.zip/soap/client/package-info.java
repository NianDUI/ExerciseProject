@javax.xml.bind.annotation.XmlSchema(namespace = "http://service.soap.niandui.top/")
package top.niandui.soap.client;
